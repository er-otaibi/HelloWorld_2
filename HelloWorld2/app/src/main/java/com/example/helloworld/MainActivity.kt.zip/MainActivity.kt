package com.example.helloworld

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import kotlin.random.Random

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

       fun sayHi(){
           Log.d("MainActivity", "Hi !")
       }

        sayHi()

        var num = Random.nextInt(3)
        when (num ){

            0 -> Log.d("MainActivity", "Random number is Zero")
            1 -> Log.d("MainActivity", "Random number is One")
            else -> Log.d("MainActivity" , "Random number is Two")
        }

        for (i in 0..3){
            Log.d("MainActivity" , "$i")
        }

        var name = "Rehab"

        if ( name == "Rehab"){
            Log.d("MainActivity", "Hello Rehab")
        }else {
            Log.d("MainActivity", "Where is Rehab ?")
        }

        var number1 = 5
        var number2 = 2


        Log.d("MainActivity", "$number1 + $number2 = ${number1+number2}")
        Log.d("MainActivity", "$number1 - $number2 = ${number1-number2}")
        Log.d("MainActivity", "$number1 * $number2 = ${number1*number2}")



    }
}